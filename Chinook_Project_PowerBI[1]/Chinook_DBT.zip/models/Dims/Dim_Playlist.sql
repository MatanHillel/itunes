{{ config(materialized='table') }}

with Dim_playlist as  
(
	select 
	p.playlistid, 
	p.trackid, 
	p2.name , 
	p.last_update,
	'{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
	from {{source('Chinook_Dims', 'playlisttrack')}} as p 
	left join  {{source('Chinook_Dims', 'playlist')}} as p2 
	on p.playlistid =p2.playlistid 
)
select 
*
from Dim_playlist

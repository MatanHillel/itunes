{{ config(materialized='table') }}


with Dim_Track as
(
	select 
	t.trackid,
	t."name" as Track_Name,
	a2.name as artist_name,
	t.composer,
	t.milliseconds,
	TO_CHAR(INTERVAL '1 second' * (t.milliseconds / 1000), 'MI:SS') AS Duration,
	t.bytes/1024/1024 as MegaBytes,
	t.unitprice,
	t.unitprice_usd,
	g."name" as Genre_Name,
	m."name" as MediaType_Name,
	a.title as Album_Title,
	t.last_update,
	'{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
	from {{source('Chinook_Dims', 'track')}} as t
	left join {{source('Chinook_Dims', 'genre')}} as g 
		on t.genreid = g.genreid 
	left join {{source('Chinook_Dims', 'mediatype')}} as m 
		on t.mediatypeid = m.mediatypeid 
	left join {{source('Chinook_Dims', 'album')}} as a 
		on a.albumid = t.albumid 
	left join {{source('Chinook_Dims', 'artist')}} as a2 
		on a.artistid = a2.artistid
)
select *
from Dim_Track
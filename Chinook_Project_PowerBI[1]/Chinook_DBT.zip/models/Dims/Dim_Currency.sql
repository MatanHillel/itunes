{{ config(materialized='table') }}

with Dim_currency as  
(
	select 
	*,
	'{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
	from {{source('Chinook_Dims', 'Exchange_Table')}}
)
select 
*
from Dim_currency
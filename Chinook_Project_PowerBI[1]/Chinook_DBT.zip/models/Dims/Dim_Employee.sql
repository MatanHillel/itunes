{{ config(materialized='table') }}


with Dim_employee as
(
	select 
		e.employeeid,
		concat(e.lastname, ' ' , e.firstname) as FullName,
		e.title,
		(extract(year from current_date) - extract(year from e.hiredate)) as seniority_years,
		e.reportsto,
		e.departmentid,
		dt.department_name,
		dt."Total Budget", 
		e.birthdate,
		e.hiredate,
		e.address,
		e.city,
		e.state,
		e.country,
		e.postalcode,
		e.phone,
		e.fax,
		e.email,
		SUBSTRING(email,position('@' in email)) as Email_Domain,
		'{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time,
		e.last_update 
	from {{source('Chinook_Dims', 'employee')}} as e
	left join {{source('Chinook_Dims', 'Department_Table')}} as dt 
		on dt.department_id = e.departmentid 
),
chacking_manger as 
(
SELECT
	*,
    CASE 
        WHEN employeeid IN (SELECT DISTINCT reportsto FROM Dim_employee WHERE reportsto IS NOT NULL) THEN TRUE
        ELSE FALSE
    END AS is_manager_flag
FROM Dim_employee
)
select *
from chacking_manger

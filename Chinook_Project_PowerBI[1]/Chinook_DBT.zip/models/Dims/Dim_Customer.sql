{{ config(materialized='table') }}

with Dim_Customer as
(
	SELECT 
	customerid, 
	CONCAT(UPPER(SUBSTRING(firstname, 1, 1)), LOWER(SUBSTRING(firstname, 2, 20))) as FirstName,
	CONCAT(UPPER(SUBSTRING(lastname, 1, 1)), LOWER(SUBSTRING(lastname, 2, 20))) as LastName,
	company,
	address,
	city,
	state,
	country,
	postalcode,
	fax,
	email,
	SUBSTRING(email, position ('@' in email)) as EmailDomain,
	supportrepid,
	last_update,
	'{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
 	FROM {{source('Chinook_Dims', 'customer')}}
)
select *
from Dim_Customer
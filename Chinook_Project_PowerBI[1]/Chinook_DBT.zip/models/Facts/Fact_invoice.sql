{{config(materialized='table',unique_key='invoiceid')}}

with Fact_Invoice as
(
	select invoiceid,
	customerid,
	"Date_invoice",
	"total_ILS",
	i.total,
	last_update,
    '{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
	from {{source('Chinook_facts', 'invoice')}}  as i 
)
select *
from Fact_Invoice
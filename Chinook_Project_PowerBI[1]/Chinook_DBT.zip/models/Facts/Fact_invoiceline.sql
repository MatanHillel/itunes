{{config(materialized='table',unique_key='invoicelineid')}}

with Fact_Invoiceline as
(
	select 
	il.invoicelineid,
	il.invoiceid,
	il.quantity,
	il.unitprice_usd,
	il.unitprice as unitprice_ILS,
	t.trackid,
	t.Genre_Name,
	t.milliseconds,
	t.composer,
	t.megabytes,
	il.last_update,
	'{{ run_started_at.strftime ("%Y-%m-%d %H:%M:%S")}}'::timestamp as dbt_time
	from {{source('Chinook_facts', 'invoiceline')}} as il
	left join {{ref('Dim_Track')}} as t
		on t.trackid = il.trackid 
)
select *
from Fact_Invoiceline



